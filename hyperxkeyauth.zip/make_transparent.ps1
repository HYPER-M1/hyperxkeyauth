Add-Type -AssemblyName System.Drawing

function Remove-BlackBackground {
    param (
        [string]$InputPath,
        [string]$OutputPath,
        [int]$Threshold = 35
    )

    $img = [System.Drawing.Image]::FromFile($InputPath)
    $bmp = New-Object System.Drawing.Bitmap($img.Width, $img.Height, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.DrawImage($img, 0, 0, $img.Width, $img.Height)
    $g.Dispose()
    $img.Dispose()

    for ($y = 0; $y -lt $bmp.Height; $y++) {
        for ($x = 0; $x -lt $bmp.Width; $x++) {
            $p = $bmp.GetPixel($x, $y)
            # Check maximum channel intensity
            $maxC = [Math]::Max($p.R, [Math]::Max($p.G, $p.B))
            
            if ($maxC -le $Threshold) {
                # Completely transparent
                $bmp.SetPixel($x, $y, [System.Drawing.Color]::FromArgb(0, 0, 0, 0))
            } elseif ($maxC -lt ($Threshold + 30)) {
                # Smooth transition / anti-aliasing feathering
                $factor = ($maxC - $Threshold) / 30.0
                $alpha = [int](255 * $factor)
                $bmp.SetPixel($x, $y, [System.Drawing.Color]::FromArgb($alpha, $p.R, $p.G, $p.B))
            }
        }
    }

    $bmp.Save($OutputPath, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
    Write-Host "Processed $InputPath -> $OutputPath"
}

$dir = "C:\Users\manis\.gemini\antigravity\scratch\prtvshow-admin\assets\images"
Remove-BlackBackground "$dir\hx_card_logo.png" "$dir\hx_card_logo_clean.png" 35
Remove-BlackBackground "$dir\hx_nav_logo.png" "$dir\hx_nav_logo_clean.png" 35
