@echo off
title HYPER X - KeyAuth Localhost Server
echo ========================================================
echo  Starting HYPER X KeyAuth Localhost Server on Port 8080...
echo ========================================================
echo.
echo Opening browser at http://localhost:8080 ...
start http://localhost:8080
echo.
powershell -ExecutionPolicy Bypass -File "%~dp0server.ps1"
pause
