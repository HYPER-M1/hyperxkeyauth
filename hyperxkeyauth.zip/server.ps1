$port = 8080
$rootDir = $PSScriptRoot

$API_URL = "https://prtvshow.online/api_admin.php"
$API_KEY = "TX999_API_bc186f5d73bd492e6d52095e5a7bfd78"
$APP_ID  = "9f087d585fbd666572fc24b7"

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")
$listener.Prefixes.Add("http://127.0.0.1:$port/")

# Add all active local network IPs so phone can connect
try {
    $localIPs = Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notmatch '^127\.' -and $_.IPAddress -notmatch '^169\.254\.' } | Select-Object -ExpandProperty IPAddress
    foreach ($ip in $localIPs) {
        $listener.Prefixes.Add("http://${ip}:$port/")
    }
} catch {}

$listener.Start()

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host " HYPER X KeyAuth Web Portal & API Proxy Server" -ForegroundColor Green
Write-Host " Local URL : http://localhost:$port/" -ForegroundColor White
Write-Host " Live API  : $API_URL" -ForegroundColor Yellow
Write-Host " Serving   : $rootDir" -ForegroundColor DarkGray
Write-Host " Status    : READY (Press Ctrl+C to stop)" -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan

$mimeTypes = @{
    ".html" = "text/html; charset=utf-8"
    ".htm"  = "text/html; charset=utf-8"
    ".css"  = "text/css; charset=utf-8"
    ".js"   = "application/javascript; charset=utf-8"
    ".json" = "application/json; charset=utf-8"
    ".png"  = "image/png"
    ".jpg"  = "image/jpeg"
    ".jpeg" = "image/jpeg"
    ".gif"  = "image/gif"
    ".svg"  = "image/svg+xml"
    ".ico"  = "image/x-icon"
    ".txt"  = "text/plain; charset=utf-8"
}

while ($listener.IsListening) {
    try {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response

        # Enable CORS for all incoming requests
        $response.AddHeader("Access-Control-Allow-Origin", "*")
        $response.AddHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        $response.AddHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With")

        if ($request.HttpMethod -eq "OPTIONS") {
            $response.StatusCode = 200
            $response.Close()
            continue
        }

        $urlPath = $request.Url.LocalPath.TrimStart('/')
        
        # Central Data Sync API for PC & Mobile
        if ($urlPath -eq "api/data" -or $urlPath -eq "api/data/") {
            $dataFile = Join-Path $rootDir "data.json"
            if ($request.HttpMethod -eq "GET") {
                if (Test-Path $dataFile) {
                    $jsonBytes = [System.IO.File]::ReadAllBytes($dataFile)
                } else {
                    $jsonBytes = [System.Text.Encoding]::UTF8.GetBytes("{}")
                }
                $response.ContentType = "application/json; charset=utf-8"
                $response.StatusCode = 200
                $response.OutputStream.Write($jsonBytes, 0, $jsonBytes.Length)
                $response.Close()
                continue
            }
            if ($request.HttpMethod -eq "POST") {
                $reader = New-Object System.IO.StreamReader($request.InputStream, [System.Text.Encoding]::UTF8)
                $rawBody = $reader.ReadToEnd()
                $reader.Close()
                if (-not [string]::IsNullOrWhiteSpace($rawBody)) {
                    [System.IO.File]::WriteAllText($dataFile, $rawBody, [System.Text.Encoding]::UTF8)
                }
                $okBytes = [System.Text.Encoding]::UTF8.GetBytes('{"success":true}')
                $response.ContentType = "application/json; charset=utf-8"
                $response.StatusCode = 200
                $response.OutputStream.Write($okBytes, 0, $okBytes.Length)
                $response.Close()
                continue
            }
        }

        # Check if request is an API proxy call
        if ($urlPath -eq "api" -or $urlPath -eq "api/" -or $urlPath -eq "admin_api.php" -or $urlPath -eq "admin/api.php") {
            try {
                $reader = New-Object System.IO.StreamReader($request.InputStream, [System.Text.Encoding]::UTF8)
                $rawBody = $reader.ReadToEnd()
                $reader.Close()

                $payload = @{}
                if (-not [string]::IsNullOrWhiteSpace($rawBody)) {
                    $parsed = $rawBody | ConvertFrom-Json
                    foreach ($prop in $parsed.PSObject.Properties) {
                        $payload[$prop.Name] = $prop.Value
                    }
                }

                # Ensure Master API Credentials
                if (-not $payload.ContainsKey("api_key") -or [string]::IsNullOrWhiteSpace($payload["api_key"])) {
                    $payload["api_key"] = $API_KEY
                }
                if (-not $payload.ContainsKey("app_id") -or [string]::IsNullOrWhiteSpace($payload["app_id"])) {
                    $payload["app_id"] = $APP_ID
                }

                $action = if ($payload.ContainsKey("action")) { $payload["action"] } else { "unknown" }
                Write-Host "[API PROXY] Forwarding action: '$action' to remote server..." -ForegroundColor Magenta

                $forwardJson = $payload | ConvertTo-Json -Depth 10

                $respString = ""
                try {
                    $apiResp = Invoke-RestMethod -Uri $API_URL -Method Post -Body $forwardJson -ContentType "application/json" -TimeoutSec 15
                    $respString = $apiResp | ConvertTo-Json -Depth 10
                    Write-Host "[API PROXY] [OK] Action '$action' succeeded" -ForegroundColor Green
                } catch {
                    if ($_.Exception.Response) {
                        $stream = $_.Exception.Response.GetResponseStream()
                        $errReader = New-Object System.IO.StreamReader($stream)
                        $respString = $errReader.ReadToEnd()
                        $errReader.Close()
                    } else {
                        $respString = @{ success = $false; message = $_.Exception.Message } | ConvertTo-Json
                    }
                    Write-Host "[API PROXY] [WARN] Action '$action' response received with note" -ForegroundColor Yellow
                }

                $respBytes = [System.Text.Encoding]::UTF8.GetBytes($respString)
                $response.ContentType = "application/json; charset=utf-8"
                $response.StatusCode = 200
                $response.OutputStream.Write($respBytes, 0, $respBytes.Length)
            } catch {
                $errMsgText = $_.ToString()
                $errMsg = @{ success = $false; message = "Internal Proxy Error: $errMsgText" } | ConvertTo-Json
                $errBytes = [System.Text.Encoding]::UTF8.GetBytes($errMsg)
                $response.ContentType = "application/json; charset=utf-8"
                $response.StatusCode = 500
                $response.OutputStream.Write($errBytes, 0, $errBytes.Length)
            }

            $response.Close()
            continue
        }

        # Static File Serving
        if ([string]::IsNullOrWhiteSpace($urlPath)) {
            $urlPath = "index.html"
        }

        # Prevent directory traversal
        $safePath = [System.IO.Path]::GetFullPath((Join-Path $rootDir $urlPath))
        if (-not $safePath.StartsWith($rootDir, [System.StringComparison]::OrdinalIgnoreCase)) {
            $response.StatusCode = 403
            $response.Close()
            continue
        }

        if (Test-Path $safePath -PathType Leaf) {
            $ext = [System.IO.Path]::GetExtension($safePath).ToLower()
            $mime = "application/octet-stream"
            if ($mimeTypes.ContainsKey($ext)) {
                $mime = $mimeTypes[$ext]
            }

            $bytes = [System.IO.File]::ReadAllBytes($safePath)
            $response.ContentType = $mime
            $response.StatusCode = 200
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
        } else {
            $response.StatusCode = 404
            $notFoundMsg = [System.Text.Encoding]::UTF8.GetBytes("404 Not Found: $urlPath")
            $response.ContentType = "text/plain; charset=utf-8"
            $response.OutputStream.Write($notFoundMsg, 0, $notFoundMsg.Length)
        }

        $response.Close()
    } catch {
        # Log error for individual request, but KEEP THE SERVER RUNNING!
        $reqErr = $_.ToString()
        Write-Warning "Request error: $reqErr"
    }
}

if ($listener.IsListening) {
    $listener.Stop()
}
$listener.Close()
